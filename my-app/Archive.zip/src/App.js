import './App.css';
import Home from './component/Home';
function App() {
  return (
      <div>
        {/* <Routes>
        <Route path='/' element={<User/>} />
        <Route path='/User' element={<User/>} />
        <Route path='/Deliver' element={<User/>} /> */}
      {/* </Routes> */}
      <Home />
      </div>
  );
}

export default App;
