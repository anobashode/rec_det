import React, { Component } from 'react';
import Table from './Table';
class Deliver extends Component {
    constructor(props) {
        super(props);
        this.state = {
            orderId: ''
        };
    }
    validateOrderId = () => {
        //api call to validate order ID
    }

    validateDelivery = () => {
        //api call to validate delivery and if confirmed show alert with message from backend
    }

    updateInputValue(evt) {
        const val = evt.target.value;
        this.setState({
            orderId: val
        });
    }
    render() {
        return (
            <div>
            <div style = {{ marginTop: "140px", marginLeft: "40%", flexDirection: "column" }} >
                    <input className = "search-input mb-2"
                    type = "number"
                    onChange = { evt => this.updateInputValue(evt) }
                    placeholder = "Enter Consignment Number" />
                    <button style = {
                    {
                        backgroundColor: "#39FF14",
                        width:"60px",
                        height:"40px",
                        marginTop:"5px",
                        borderRadius:"10px"
                    }
                }
                onClick={this.validateOrderId} > >> </button> 
          </div>
          <div>
          <button style = {
                    {
                        backgroundColor: "#39FF14",
                        width:"420px",
                        height:"50px",
                        marginTop:"30px",
                        marginLeft:"40%",
                        borderRadius:"10px"
                    }
                }
                onClick={this.validateDelivery} > Validate Delivery </button> 
          </div>
          <div>
              <Table />
          </div>
          </div>
        );
    }
}
export default Deliver;