import React, { Component } from 'react';
import NavBar from './NavBar';
class Home extends Component {
    render() {
        return (
            <div>
                <NavBar />
          </div>
        );
    }
}
export default Home;